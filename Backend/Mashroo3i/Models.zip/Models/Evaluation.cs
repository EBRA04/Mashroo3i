﻿namespace Mashroo3i.Models
{
    public class Evaluation
    {
    }
}
